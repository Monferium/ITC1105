<?php
// Start session if you plan to use sessions
session_start();

// Check if the form has been submitted and the required POST variables are set
if (isset($_POST['username']) && isset($_POST['password'])) {
    // Assign the POST data to variables
    $newUsername = $_POST['username'];
    $originalPassword = $_POST['password'];

    // Now check if the username already exists in the database
    $conn = new mysqli('localhost', 'root', 'Monferium1945', 'dbms_3306-main', 3306);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare a statement to check if the username exists
    $check_stmt = $conn->prepare("SELECT username FROM user_table WHERE username = ?");
    $check_stmt->bind_param("s", $newUsername);
    $check_stmt->execute();
    $check_stmt->store_result();

    // If a row is found, the username already exists
    if ($check_stmt->num_rows > 0) {
        echo "Username already exists. Please choose a different username.";
    } else {
        // Hash the password
        $hashedPassword = password_hash($originalPassword, PASSWORD_DEFAULT);

        // Prepare the insert statement
        $insert_stmt = $conn->prepare("INSERT INTO user_table (username, password) VALUES (?, ?)");
        $insert_stmt->bind_param("ss", $newUsername, $hashedPassword);

        // Execute and check for success
        if ($insert_stmt->execute()) {
            echo "New user registered successfully!";
        } else {
            echo "Error: " . $insert_stmt->error;
        }

        // Close insert statement
        $insert_stmt->close();
    }

    // Close check statement, connection
    $check_stmt->close();
    $conn->close();
} else {
    // Not all POST variables are set, or the form has not been submitted
    echo "Required data is missing.";
}
?>
