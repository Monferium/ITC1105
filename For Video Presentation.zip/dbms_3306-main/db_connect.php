<?php
$servername = "localhost";
$username = "root";
$password = "Monferium1945";
$dbname = 'dbms_3306-main'; // your database name
$newPort = 3306; // The new port number you're using for MySQL

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $newPort);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
